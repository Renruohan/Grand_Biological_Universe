Genome convex hull analysis and tree construction with 24719 sequences in 425 families

Considering the optimal metric in Bacteria

The node name of the tree is "family--class". 

It can be seen that overall the sequences of the same class are relatively close in the tree.
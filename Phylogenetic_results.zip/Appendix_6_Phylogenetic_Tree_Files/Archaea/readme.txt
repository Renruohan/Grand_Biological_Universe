Genome convex hull analysis and tree construction

Considering the optimal metric in Archaea

The node name of the tree is "phylum". 
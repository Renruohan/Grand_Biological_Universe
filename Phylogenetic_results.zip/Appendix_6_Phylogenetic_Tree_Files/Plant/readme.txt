Chloroplast convex hull analysis and tree construction

Considering the optimal metric in plants

The node name of the tree is "family--ophyta".

It can be seen that overall the sequences of the same ophyta are relatively close in the tree.
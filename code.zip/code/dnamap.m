function [index] = dnamap(letter)
% letter 格式为 'A'
% dnamap 将 A/a，C/c，G/g，T/t 对应四进制数

    if (letter == 'A' || letter == 'a')
        index = 0;
    elseif (letter == 'C' || letter == 'c')
        index = 1;
    elseif (letter == 'G' || letter == 'g')
        index = 2;
    elseif (letter == 'T' || letter == 't')
        index = 3;
    else
        index = 4;
    end
end
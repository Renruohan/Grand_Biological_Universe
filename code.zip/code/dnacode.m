function [ind] = dnacode(k,seq)
% k 为 seq 的长度（正整数），seq 为待映射的 kmer 片段（'ACGT'）
% dnacode 用来将长为 k 的 seq 映射为一个数

ind = 0;
% seq 对应的数

    for i = 1 : k
        t = dnamap(seq(i)); % dnamap 将 A,C,G,T 分别映射为 0,1,2,3
        ind = ind + t*4^(i - 1); % 四进制构造
    end
end
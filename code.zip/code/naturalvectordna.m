function [result]=naturalvectordna(sequence)
 for k = 1: length(sequence)
        if strcmp(sequence(k),'A')||strcmp(sequence(k),'a');       
            vector(k)=1;
            k=k+1;
        elseif strcmp(sequence(k),'C')||strcmp(sequence(k),'c');
            vector(k)=2;
            k=k+1;
        elseif strcmp(sequence(k),'G')||strcmp(sequence(k),'g');
            vector(k)=3;
            k=k+1;
        elseif strcmp(sequence(k),'U'||strcmp(sequence(k),'u'));
            vector(k)=4;
            k=k+1;
        elseif strcmp(sequence(k),'T')||strcmp(sequence(k),'t');
            vector(k)=4;
            k=k+1;
        end
 end
    
    nA=0;TA=0;nC=0;TC=0;nG=0;TG=0;nT=0;TT=0;
    tA=[];tC=[];tG=[];tT=[];
    a=1;c=1;g=1;u=1;
    nn=0;DA=0;DC=0;DG=0;DT=0;
 
    for x=1:length(vector) %compute ni and Ti and tj%
       if vector(x)==1;%A
        nA=nA+1;
        TA=TA+(x);
        tA(a)=x; 
        a=a+1;
       elseif vector(x)==2;%C
        nC=nC+1;
         TC=TC+(x);
        tC(c)=x;
        c=c+1; 
       elseif vector(x)==3;%G
        nG=nG+1;
        TG=TG+(x);
        tG(g)=x; % tg%
        g=g+1;
       elseif vector(x)==4;%U����T
        nT=nT+1;
        TT=TT+(x);
        tT(u)=x; % tg%
        u=u+1;
       end
    end
    
    uA=TA/nA;
    uC=TC/nC;
    uG=TG/nG;
    uT=TT/nT;
    
    
    nn=length(vector);
    DA=sum((tA-uA).^2)/(nA*nn);
    DC=sum((tC-uC).^2)/(nC*nn);
    DG=sum((tG-uG).^2)/(nG*nn);
    DT=sum((tT-uT).^2)/(nT*nn);
   
     
    DA3=sum((tA-uA).^3)/(nA^2*nn^2);
    DC3=sum((tC-uC).^3)/(nC^2*nn^2);
    DG3=sum((tG-uG).^3)/(nG^2*nn^2);
    DT3=sum((tT-uT).^3)/(nT^2*nn^2);
    
    DA4=sum((tA-uA).^4)/(nA^3*nn^3);
    DC4=sum((tC-uC).^4)/(nC^3*nn^3);
    DG4=sum((tG-uG).^4)/(nG^3*nn^3);
    DT4=sum((tT-uT).^4)/(nT^3*nn^3);
    
    DA5=sum((tA-uA).^5)/(nA^4*nn^4);
    DC5=sum((tC-uC).^5)/(nC^4*nn^4);
    DG5=sum((tG-uG).^5)/(nG^4*nn^4);
    DT5=sum((tT-uT).^5)/(nT^4*nn^4);   
    
    DA6=sum((tA-uA).^6)/(nA^5*nn^5);
    DC6=sum((tC-uC).^6)/(nC^5*nn^5);
    DG6=sum((tG-uG).^6)/(nG^5*nn^5);
    DT6=sum((tT-uT).^6)/(nT^5*nn^5); 
    
    DA7=sum((tA-uA).^7)/(nA^6*nn^6);
    DC7=sum((tC-uC).^7)/(nC^6*nn^6);
    DG7=sum((tG-uG).^7)/(nG^6*nn^6);
    DT7=sum((tT-uT).^7)/(nT^6*nn^6); 

    DA8=sum((tA-uA).^8)/(nA^7*nn^7);
    DC8=sum((tC-uC).^8)/(nC^7*nn^7);
    DG8=sum((tG-uG).^8)/(nG^7*nn^7);
    DT8=sum((tT-uT).^8)/(nT^7*nn^7); 

    DA9=sum((tA-uA).^9)/(nA^8*nn^8);
    DC9=sum((tC-uC).^9)/(nC^8*nn^8);
    DG9=sum((tG-uG).^9)/(nG^8*nn^8);
    DT9=sum((tT-uT).^9)/(nT^8*nn^8); 
    
    DA10=sum((tA-uA).^10)/(nA^9*nn^9);
    DC10=sum((tC-uC).^10)/(nC^9*nn^9);
    DG10=sum((tG-uG).^10)/(nG^9*nn^9);
    DT10=sum((tT-uT).^10)/(nT^9*nn^9); 

    DA11=sum((tA-uA).^11)/(nA^10*nn^10);
    DC11=sum((tC-uC).^11)/(nC^10*nn^10);
    DG11=sum((tG-uG).^11)/(nG^10*nn^10);
    DT11=sum((tT-uT).^11)/(nT^10*nn^10);

    DA12=sum((tA-uA).^12)/(nA^11*nn^11);
    DC12=sum((tC-uC).^12)/(nC^11*nn^11);
    DG12=sum((tG-uG).^12)/(nG^11*nn^11);
    DT12=sum((tT-uT).^12)/(nT^11*nn^11);
    
    DA13=sum((tA-uA).^13)/(nA^12*nn^12);
    DC13=sum((tC-uC).^13)/(nC^12*nn^12);
    DG13=sum((tG-uG).^13)/(nG^12*nn^12);
    DT13=sum((tT-uT).^13)/(nT^12*nn^12);    

    DA14=sum((tA-uA).^14)/(nA^13*nn^13);
    DC14=sum((tC-uC).^14)/(nC^13*nn^13);
    DG14=sum((tG-uG).^14)/(nG^13*nn^13);
    DT14=sum((tT-uT).^14)/(nT^13*nn^13);    
 
    DA15=sum((tA-uA).^15)/(nA^14*nn^14);
    DC15=sum((tC-uC).^15)/(nC^14*nn^14);
    DG15=sum((tG-uG).^15)/(nG^14*nn^14);
    DT15=sum((tT-uT).^15)/(nT^14*nn^14);  

    DA16=sum((tA-uA).^16)/(nA^15*nn^15);
    DC16=sum((tC-uC).^16)/(nC^15*nn^15);
    DG16=sum((tG-uG).^16)/(nG^15*nn^15);
    DT16=sum((tT-uT).^16)/(nT^15*nn^15); 
   
    DA17=sum((tA-uA).^17)/(nA^16*nn^16);
    DC17=sum((tC-uC).^17)/(nC^16*nn^16);
    DG17=sum((tG-uG).^17)/(nG^16*nn^16);
    DT17=sum((tT-uT).^17)/(nT^16*nn^16); 
    
    DA18=sum((tA-uA).^18)/(nA^16*nn^17);
    DC18=sum((tC-uC).^18)/(nC^16*nn^17);
    DG18=sum((tG-uG).^18)/(nG^16*nn^17);
    DT18=sum((tT-uT).^18)/(nT^16*nn^17); 
       
   result=[nA,nC,nG,nT,uA,uC,uG,uT, DA,DC,DG,DT,...
      DA3,DC3,DG3,DT3,...
      DA4,DC4,DG4,DT4,...
      DA5,DC5,DG5,DT5,...
      DA6,DC6,DG6,DT6,...
      DA7,DC7,DG7,DT7,...
      DA8,DC8,DG8,DT8,...
      DA9,DC9,DG9,DT9,...
      DA10,DC10,DG10,DT10,...
      DA11,DC11,DG11,DT11,...
      DA12,DC12,DG12,DT12,...
      DA13,DC13,DG13,DT13,...
      DA14,DC14,DG14,DT14,...
      DA15,DC15,DG15,DT15,...
      DA16,DC16,DG16,DT16,...
      DA17,DC17,DG17,DT17,...
      DA18,DC18,DG18,DT18];
  
end
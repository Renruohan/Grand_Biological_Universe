# README





计算出的knv和距离矩阵在服务器文件夹：BioData/Grand_Biological_Map/kmernv_1NN


